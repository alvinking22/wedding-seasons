<?php

namespace Google\Site_Kit_Dependencies\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
