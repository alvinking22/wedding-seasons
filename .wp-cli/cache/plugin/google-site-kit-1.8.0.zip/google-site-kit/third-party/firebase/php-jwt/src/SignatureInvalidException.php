<?php

namespace Google\Site_Kit_Dependencies\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
